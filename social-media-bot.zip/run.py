from app import InstagramBotApp

if __name__ == "__main__":
    app = InstagramBotApp()
    app.run()