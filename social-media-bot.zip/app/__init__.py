import tkinter as tk
from tkinter import ttk, messagebox
from .services.instagram.account import InstagramAccountService
from .services.instagram.interaction import InstagramInteractionService

from .ui.tabs import AccountsTab, CommentsTab
class InstagramBotApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Instagram Bot Manager")
        self.root.geometry("800x600")
        
        # Initialize services
        self.account_service = InstagramAccountService()
        self.interaction_service = InstagramInteractionService(self.account_service)
        
        self.create_widgets()

    def create_widgets(self):
        # Create notebook and tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(expand=True, fill='both', padx=10, pady=10)
        
        # Create tabs
        self.accounts_tab = AccountsTab(self.notebook, self.account_service)
        self.comments_tab = CommentsTab(self.notebook, self.interaction_service)
        
        self.notebook.add(self.accounts_tab, text='Accounts')
        self.notebook.add(self.comments_tab, text='Comments')

    def run(self):
        self.root.mainloop()