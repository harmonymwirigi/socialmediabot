from .browser import InstagramBrowser
import threading
import queue
import logging

class InstagramInteractionService:
    def __init__(self, account_service):
        self.account_service = account_service
        self.browser = InstagramBrowser()
        self.logger = logging.getLogger(__name__)
    
    def comment_on_post(self, post_url, comments):
        # Get active accounts
        accounts = self.account_service.get_active_accounts()
        
        # If no accounts, raise an exception
        if not accounts:
            raise Exception("No active Instagram accounts available")
        
        # If number of comments <= number of accounts, map one comment per account
        if len(comments) <= len(accounts):
            return self._comment_with_account_mapping(post_url, comments, accounts)
        
        # If more comments than accounts, cycle through accounts
        return self._comment_with_account_cycling(post_url, comments, accounts)
    
    def _comment_with_account_mapping(self, post_url, comments, accounts):
        """
        Assigns one comment to each account when comments <= accounts
        """
        results_queue = queue.Queue()
        threads = []
        
        def comment_worker(account, comment):
            username = account[0]
            password = self.account_service.fernet.decrypt(account[1]).decode()
            
            try:
                # Login 
                driver = self.browser.login(username, password)
                
                # Post comment
                success = self.browser.post_comment(driver, post_url, comment)
                driver.quit()
                
                if success:
                    self.account_service.update_last_used(username)
                
                results_queue.put({
                    'username': username,
                    'comment': comment,
                    'success': success,
                    'error': None
                })
            
            except Exception as e:
                results_queue.put({
                    'username': username,
                    'comment': comment,
                    'success': False,
                    'error': str(e)
                })
        
        # Create threads for comments
        for i, comment in enumerate(comments):
            if i < len(accounts):
                thread = threading.Thread(
                    target=comment_worker, 
                    args=(accounts[i], comment)
                )
                threads.append(thread)
                thread.start()
        
        # Wait for all threads to complete
        for thread in threads:
            thread.join()
        
        # Collect results
        results = []
        while not results_queue.empty():
            results.append(results_queue.get())
        
        return results
    
    def _comment_with_account_cycling(self, post_url, comments, accounts):
        """
        Cycles through accounts when comments > accounts
        Reuses first account if insufficient accounts
        """
        results_queue = queue.Queue()
        threads = []
        
        def comment_worker(account, comment):
            username = account[0]
            password = self.account_service.fernet.decrypt(account[1]).decode()
            
            try:
                # Login 
                driver = self.browser.login(username, password)
                
                # Post comment
                success = self.browser.post_comment(driver, post_url, comment)
                driver.quit()
                
                if success:
                    self.account_service.update_last_used(username)
                
                results_queue.put({
                    'username': username,
                    'comment': comment,
                    'success': success,
                    'error': None
                })
            
            except Exception as e:
                results_queue.put({
                    'username': username,
                    'comment': comment,
                    'success': False,
                    'error': str(e)
                })
        
        # Create threads for comments
        for i, comment in enumerate(comments):
            # Cycle through accounts, using first account again if needed
            account = accounts[i % len(accounts)]
            thread = threading.Thread(
                target=comment_worker, 
                args=(account, comment)
            )
            threads.append(thread)
            thread.start()
        
        # Wait for all threads to complete
        for thread in threads:
            thread.join()
        
        # Collect results
        results = []
        while not results_queue.empty():
            results.append(results_queue.get())
        
        return results