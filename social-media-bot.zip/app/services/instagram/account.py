from cryptography.fernet import Fernet
import os
from ...database import Database

class InstagramAccountService:
    def __init__(self):
        self.db = Database()
        self._init_encryption()
    
    def _init_encryption(self):
        if not os.path.exists('secret.key'):
            key = Fernet.generate_key()
            with open('secret.key', 'wb') as key_file:
                key_file.write(key)
        
        with open('secret.key', 'rb') as key_file:
            self.key = key_file.read()
        self.fernet = Fernet(self.key)
    
    def add_account(self, username, password):
        encrypted_password = self.fernet.encrypt(password.encode())
        return self.db.execute(
            'INSERT INTO accounts (username, encrypted_password) VALUES (?, ?)',
            (username, encrypted_password)
        )
    
    def update_account_status(self, username, is_active):
        """Update account active status"""
        return self.db.execute(
            'UPDATE accounts SET is_active = ? WHERE username = ?',
            (is_active, username)
        )
    def get_accounts(self):
        return self.db.fetch_all('SELECT username, is_active, last_used FROM accounts')
    
    def get_active_accounts(self):
        return self.db.fetch_all(
            'SELECT username, encrypted_password FROM accounts WHERE is_active = 1'
        )
    def update_last_used(self, username):
        """Update the last used timestamp for an account"""
        import datetime
        return self.db.execute(
            'UPDATE accounts SET last_used = ? WHERE username = ?', 
            (datetime.datetime.now(), username)
        )