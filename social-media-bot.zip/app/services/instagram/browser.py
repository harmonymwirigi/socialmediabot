from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import pickle
import os
import time
import random
import logging
from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
import traceback


class InstagramBrowser:
    def __init__(self):
        self.base_url = "https://www.instagram.com"
        self.cookies_dir = "browser_data/cookies"
        os.makedirs(self.cookies_dir, exist_ok=True)
    
    def _create_driver(self):
        options = webdriver.ChromeOptions()
        # Add options to make browser less detectable
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        return webdriver.Chrome(options=options)
    
    def _get_cookie_path(self, username):
        return os.path.join(self.cookies_dir, f"{username}_cookies.pkl")
    
    def _save_cookies(self, driver, username):
        cookie_path = self._get_cookie_path(username)
        pickle.dump(driver.get_cookies(), open(cookie_path, "wb"))
    
    def _load_cookies(self, driver, username):
        cookie_path = self._get_cookie_path(username)
        if os.path.exists(cookie_path):
            cookies = pickle.load(open(cookie_path, "rb"))
            for cookie in cookies:
                driver.add_cookie(cookie)
            return True
        return False
    
    def _random_delay(self, min_seconds=1, max_seconds=3):
        time.sleep(random.uniform(min_seconds, max_seconds))
    
    def login(self, username, password):
        driver = self._create_driver()
        try:
            # First try to load cookies
            driver.get(self.base_url)
            if self._load_cookies(driver, username):
                driver.refresh()
                if "login" not in driver.current_url:
                    return driver
            
            # If cookies don't work, perform manual login
            driver.get(f"{self.base_url}/accounts/login/")
            self._random_delay()
            
            # Wait for and fill username field
            username_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.NAME, "username"))
            )
            username_input.send_keys(username)
            
            # Fill password field
            password_input = driver.find_element(By.NAME, "password")
            password_input.send_keys(password)
            
            # Click login button
            login_button = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
            login_button.click()
            
            # Wait for login to complete
            WebDriverWait(driver, 10).until(
                lambda d: "login" not in d.current_url
            )
            
            # Save cookies for future use
            self._save_cookies(driver, username)
            
            return driver
            
        except Exception as e:
            driver.quit()
            raise Exception(f"Login failed: {str(e)}")
    
    def post_comment(self, driver, post_url, comment):
        logger = logging.getLogger(__name__)
        
        try:
            # Navigate to post
            logger.info(f"Navigating to post URL: {post_url}")
            driver.get(post_url)
            self._random_delay()
            
            # Wait for page to load
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, 'body'))
            )
            
            # Multiple strategies to find and interact with textarea
            def find_and_interact_with_textarea():
                # Try multiple locators
                textarea_locators = [
                    (By.CSS_SELECTOR, "textarea[aria-label='Add a comment…']"),
                    (By.XPATH, "//textarea[@aria-label='Add a comment…']"),
                    (By.XPATH, "//form//textarea[contains(@placeholder, 'Add a comment')]")
                ]
                
                for locator_type, locator_value in textarea_locators:
                    try:
                        # Wait for textarea to be present and visible
                        textarea = WebDriverWait(driver, 5).until(
                            EC.presence_of_element_located((locator_type, locator_value))
                        )
                        
                        # Ensure textarea is in view
                        driver.execute_script("arguments[0].scrollIntoView(true);", textarea)
                        time.sleep(0.5)
                        
                        # Try multiple interaction methods
                        try:
                            textarea.click()
                        except Exception:
                            driver.execute_script("arguments[0].click();", textarea)
                        
                        time.sleep(0.5)
                        
                        # Type comment character by character
                        for char in comment:
                            try:
                                textarea.send_keys(char)
                            except StaleElementReferenceException:
                                # Relocate textarea if stale
                                textarea = WebDriverWait(driver, 5).until(
                                    EC.presence_of_element_located((locator_type, locator_value))
                                )
                                textarea.send_keys(char)
                            time.sleep(random.uniform(0.1, 0.3))
                        
                        return textarea
                    
                    except TimeoutException:
                        logger.warning(f"Could not find textarea with {locator_type}: {locator_value}")
                
                raise Exception("Could not find comment textarea")
            
            # Find and interact with textarea
            textarea = find_and_interact_with_textarea()
            
            # Find post button
            def find_and_click_post_button():
                post_button_locators = [
                    (By.XPATH, "//div[@role='button' and contains(text(), 'Post')]"),
                    (By.XPATH, "//div[@role='button' and contains(@class, 'x1i10hfl') and contains(text(), 'Post')]"),
                    (By.CSS_SELECTOR, "div[role='button'][tabindex='0']"),
                    (By.XPATH, "//form//div[@role='button' and @tabindex='0']")
                ]
                
                for locator_type, locator_value in post_button_locators:
                    try:
                        # Wait for post button to be clickable
                        post_button = WebDriverWait(driver, 5).until(
                            EC.element_to_be_clickable((locator_type, locator_value))
                        )
                        
                        # Scroll into view
                        driver.execute_script("arguments[0].scrollIntoView(true);", post_button)
                        time.sleep(0.5)
                        
                        # Try multiple click methods
                        try:
                            post_button.click()
                        except Exception:
                            driver.execute_script("arguments[0].click();", post_button)
                        
                        return True
                    
                    except TimeoutException:
                        logger.warning(f"Could not find post button with {locator_type}: {locator_value}")
                
                raise Exception("Could not find post button")
            
            # Find and click post button
            find_and_click_post_button()
            
            # Wait for comment to be posted
            self._random_delay(2, 4)
            
            logger.info("Comment posted successfully")
            return True
        
        except Exception as e:
            logger.error(f"Comment failed: {str(e)}")
            # Optional: capture page source for debugging
            try:
                logger.error("Page source:")
                logger.error(driver.page_source)
            except Exception:
                pass
            raise