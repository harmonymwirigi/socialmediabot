# app/ui/tabs.py
import tkinter as tk
from tkinter import ttk, messagebox

class AccountsTab(ttk.Frame):
    def __init__(self, parent, account_service):
        super().__init__(parent)
        self.account_service = account_service
        
        self.setup_add_account_frame()
        self.setup_accounts_list()
        self.load_accounts()
    
    def setup_add_account_frame(self):
        # Add Account Frame
        add_frame = ttk.LabelFrame(self, text="Add Instagram Account")
        add_frame.pack(fill='x', padx=5, pady=5)
        
        # Username field
        ttk.Label(add_frame, text="Username:").grid(row=0, column=0, padx=5, pady=5)
        self.username_var = tk.StringVar()
        ttk.Entry(add_frame, textvariable=self.username_var).grid(row=0, column=1, padx=5, pady=5)
        
        # Password field
        ttk.Label(add_frame, text="Password:").grid(row=1, column=0, padx=5, pady=5)
        self.password_var = tk.StringVar()
        ttk.Entry(add_frame, textvariable=self.password_var, show="*").grid(row=1, column=1, padx=5, pady=5)
        
        # Add button
        ttk.Button(add_frame, text="Add Account", command=self.add_account).grid(row=2, column=0, columnspan=2, pady=10)
    
    def setup_accounts_list(self):
        # Accounts List Frame
        list_frame = ttk.LabelFrame(self, text="Accounts List")
        list_frame.pack(fill='both', expand=True, padx=5, pady=5)
        
        # Create Treeview
        columns = ('Username', 'Status', 'Last Used')
        self.accounts_tree = ttk.Treeview(list_frame, columns=columns, show='headings')
        
        # Configure columns
        for col in columns:
            self.accounts_tree.heading(col, text=col)
            self.accounts_tree.column(col, width=100)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(list_frame, orient='vertical', command=self.accounts_tree.yview)
        self.accounts_tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack widgets
        self.accounts_tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
    
    def add_account(self):
        username = self.username_var.get()
        password = self.password_var.get()
        
        if not username or not password:
            messagebox.showerror("Error", "Please fill in both username and password")
            return
        
        try:
            self.account_service.add_account(username, password)
            messagebox.showinfo("Success", f"Account {username} added successfully")
            self.username_var.set("")
            self.password_var.set("")
            self.load_accounts()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to add account: {str(e)}")
    
    def load_accounts(self):
        # Clear existing items
        for item in self.accounts_tree.get_children():
            self.accounts_tree.delete(item)
        
        # Load accounts from service
        accounts = self.account_service.get_accounts()
        for account in accounts:
            status = "Active" if account[1] else "Inactive"
            self.accounts_tree.insert('', 'end', values=(account[0], status, account[2]))

class CommentsTab(ttk.Frame):
    def __init__(self, parent, interaction_service):
        super().__init__(parent)
        self.interaction_service = interaction_service
        
        self.setup_url_frame()
        self.setup_comments_frame()
        self.setup_control_frame()
    
    def setup_url_frame(self):
        # URL Frame
        url_frame = ttk.LabelFrame(self, text="Target Post")
        url_frame.pack(fill='x', padx=5, pady=5)
        
        # URL Entry
        ttk.Label(url_frame, text="Post URL:").pack(side='left', padx=5)
        self.url_var = tk.StringVar()
        ttk.Entry(url_frame, textvariable=self.url_var, width=50).pack(
            side='left', padx=5, pady=5, fill='x', expand=True
        )
    
    def setup_comments_frame(self):
        # Comments Frame
        comments_frame = ttk.LabelFrame(self, text="Comments (One per line)")
        comments_frame.pack(fill='both', expand=True, padx=5, pady=5)
        
        # Comments Text area with scrollbar
        self.comments_text = tk.Text(comments_frame, height=10)
        scrollbar = ttk.Scrollbar(comments_frame, orient='vertical', command=self.comments_text.yview)
        self.comments_text.configure(yscrollcommand=scrollbar.set)
        
        self.comments_text.pack(side='left', fill='both', expand=True, padx=5, pady=5)
        scrollbar.pack(side='right', fill='y')
    
    def setup_control_frame(self):
        # Control Frame
        control_frame = ttk.Frame(self)
        control_frame.pack(fill='x', padx=5, pady=5)
        
        # Progress bar
        self.progress_var = tk.DoubleVar()
        self.progress = ttk.Progressbar(
            control_frame, 
            variable=self.progress_var,
            maximum=100
        )
        self.progress.pack(fill='x', pady=5)
        
        # Start button
        ttk.Button(
            control_frame,
            text="Start Commenting",
            command=self.start_commenting
        ).pack(pady=5)
    
    def start_commenting(self):
        url = self.url_var.get()
        comments = self.comments_text.get("1.0", tk.END).strip().split('\n')
        
        if not url or not comments:
            messagebox.showerror("Error", "Please provide both URL and comments")
            return
        
        try:
            results = self.interaction_service.comment_on_post(url, comments)
            
            # Update progress bar for each result
            total = len(comments)
            successes = sum(1 for r in results if r['success'])
            self.progress_var.set((successes / total) * 100)
            
            # Show summary
            messagebox.showinfo(
                "Complete",
                f"Commenting complete: {successes}/{total} successful"
            )
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to complete commenting: {str(e)}")

